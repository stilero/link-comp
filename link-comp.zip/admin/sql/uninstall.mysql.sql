DROP TABLE IF EXISTS #__linkcontest_competition;
DROP TABLE IF EXISTS #__linkcontest_contestant;
DROP TABLE IF EXISTS #__linkcontest_winner;
